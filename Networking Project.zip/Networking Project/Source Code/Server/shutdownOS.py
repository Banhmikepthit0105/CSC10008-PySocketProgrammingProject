import os

def my_shutdown():
    os.system("shutdown /s /t 20")
